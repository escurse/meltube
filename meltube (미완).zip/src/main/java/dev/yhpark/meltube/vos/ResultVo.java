package dev.yhpark.meltube.vos;

import dev.yhpark.meltube.results.Result;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class ResultVo<TResult extends Result, TPayload> {
    private TResult result;
    private TPayload payload;
}