package dev.yhpark.meltube.vos;

import dev.yhpark.meltube.entities.MusicEntity;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MusicVo extends MusicEntity {
    private int likeCount;
    private boolean isLiked;
}