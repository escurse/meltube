package dev.yhpark.meltube.vos;

import dev.yhpark.meltube.entities.PlaylistEntity;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PlaylistVo extends PlaylistEntity {
    private int musicCount;
}