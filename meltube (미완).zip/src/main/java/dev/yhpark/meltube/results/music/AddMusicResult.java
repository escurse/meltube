package dev.yhpark.meltube.results.music;

import dev.yhpark.meltube.results.Result;

public enum AddMusicResult implements Result {
    FAILURE_DUPLICATE_YOUTUBE_ID,
}
