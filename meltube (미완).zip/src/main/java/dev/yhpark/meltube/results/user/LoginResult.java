package dev.yhpark.meltube.results.user;

import dev.yhpark.meltube.results.Result;

public enum LoginResult implements Result {
    FAILURE_NOT_VERIFIED,
    FAILURE_SUSPENDED
}