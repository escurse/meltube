package dev.yhpark.meltube.results.user;

import dev.yhpark.meltube.results.Result;

public enum ResolveRecoverPasswordResult implements Result {
    FAILURE_EXPIRED
}