package dev.yhpark.meltube.results;

public enum CommonResult implements Result {
    FAILURE,
    FAILURE_UNSIGNED,
    SUCCESS
}