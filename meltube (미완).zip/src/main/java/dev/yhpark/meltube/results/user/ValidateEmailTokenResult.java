package dev.yhpark.meltube.results.user;

import dev.yhpark.meltube.results.Result;

public enum ValidateEmailTokenResult implements Result {
    FAILURE_EXPIRED
}